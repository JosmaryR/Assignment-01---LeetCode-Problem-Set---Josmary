﻿using System;
using System.Threading;
public class Foo
{

    private ManualResetEvent firstDone = new ManualResetEvent(false);
    private ManualResetEvent secondDone = new ManualResetEvent(false);

    public Foo()
    {
    }

    public void First(Action printFirst)
    {

        printFirst();

        firstDone.Set();
    }

    public void Second(Action printSecond)
    {

        firstDone.WaitOne();

        printSecond();

        secondDone.Set();
    }

    public void Third(Action printThird)
    {
        secondDone.WaitOne();
        printThird();
    }
}