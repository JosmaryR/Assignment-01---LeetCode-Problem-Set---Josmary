﻿
public class Solution
{
    public int NumUniqueEmails(string[] emails)
    {
        HashSet<string> seenEmails = new HashSet<string>();

        foreach (string email in emails)
        {
            string[] parts = email.Split('@');
            string local = parts[0];
            string domain = parts[1];

            int plusIndex = local.IndexOf('+');
            if (plusIndex != -1)
            {
                local = local.Substring(0, plusIndex);
            }

            local = local.Replace(".", "");

            seenEmails.Add(local + "@" + domain);
        }
        return seenEmails.Count;




    }
}
