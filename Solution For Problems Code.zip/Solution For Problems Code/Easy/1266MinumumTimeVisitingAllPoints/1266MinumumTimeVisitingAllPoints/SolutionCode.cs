﻿using System;

public class Solution
{
    public int MinTimeToVisitAllPoints(int[][] points)
    {

        int totalTime = 0;


        for (int i = 0; i < points.Length - 1; i++)
        {

            int[] current = points[i];
            int[] next = points[i + 1];

            int dx = Math.Abs(next[0] - current[0]);
            int dy = Math.Abs(next[1] - current[1]);

            totalTime += Math.Max(dx, dy);
        }

        return totalTime;
    }
}