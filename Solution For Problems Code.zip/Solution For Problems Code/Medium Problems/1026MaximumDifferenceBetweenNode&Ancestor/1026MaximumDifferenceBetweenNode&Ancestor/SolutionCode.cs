﻿
using System;

public class Solution
{
    public int MaxAncestorDiff(TreeNode root)
    {

        return Helper(root, root.val, root.val);
    }

    private int Helper(TreeNode node, int currentMin, int currentMax)
    {

        if (node == null)
        {
            return currentMax - currentMin;
        }


        currentMin = Math.Min(currentMin, node.val);
        currentMax = Math.Max(currentMax, node.val);


        int leftDiff = Helper(node.left, currentMin, currentMax);
        int rightDiff = Helper(node.right, currentMin, currentMax);


        return Math.Max(leftDiff, rightDiff);
    }
}