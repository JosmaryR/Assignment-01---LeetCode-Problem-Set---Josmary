﻿using System.Text;

public class Solution
{
    public string RemoveDuplicates(string s)
    {

        StringBuilder res = new StringBuilder();

        foreach (char c in s)
        {
            int ultimaPosicion = res.Length - 1;

            if (res.Length > 0 && res[ultimaPosicion] == c)
            {

                res.Remove(ultimaPosicion, 1);
            }

            else
            {

                res.Append(c);
            }
        }

        return res.ToString();

    }
}