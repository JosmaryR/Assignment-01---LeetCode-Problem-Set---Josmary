﻿
using System;
using System.Collections.Generic;


public class Solution
{
    public IList<int> RightSideView(TreeNode root)
    {

        List<int> result = new List<int>();

        if (root == null) return result;

        Queue<TreeNode> queue = new Queue<TreeNode>();
        queue.Enqueue(root);

        while (queue.Count > 0)
        {

            int levelSize = queue.Count;

            for (int i = 0; i < levelSize; i++)
            {

                TreeNode currentNode = queue.Dequeue();

                if (i == levelSize - 1)
                {

                    result.Add(currentNode.val);

                }

                if (currentNode.left != null) queue.Enqueue(currentNode.left);
                if (currentNode.right != null) queue.Enqueue(currentNode.right);
            }
        }


        return result;
    }
}